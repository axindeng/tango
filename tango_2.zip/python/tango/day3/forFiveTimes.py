#print('My name is')
#for i in range(0,5):
#    print('Jimmy Five Times (' + str(i) + ')' )

print('My name is')
i = 0
while(i < 5):
    print('Jimmy Five Times (' + str(i) + ')')
    i = i + 1   