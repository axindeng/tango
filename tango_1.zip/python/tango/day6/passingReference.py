def eggs(someParameter):
    someParameter.append('Hello')

spam=[1,3,2]

eggs(spam)
print(spam)
