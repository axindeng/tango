#for i in range(1,11):
#    print('No.' + str(i))

i = 1
while i < 11:
    print('No.' + str(i))
    i = i + 1