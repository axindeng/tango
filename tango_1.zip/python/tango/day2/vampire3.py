name = ''
age = 120
if name == 'Alice':
    print('Hi,Alice')
elif age < 12:
    print('You are not Alice,kiddo')
else:
    print('Yor are neither Alice or a little kid')