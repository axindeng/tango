myName='Mary'
password='Mary'
name='Alice1'
if myName == 'Mary':
    print('Hello,Mary!')
if password == 'swordfish':
    print('Access granted.')
else:
    print('Wrong password.')

if name == 'Alice':
    print('Hello,Alice.')
else:
    print('Hello,stranger.')