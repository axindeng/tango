name = ''
while name != 'your name':
    print('please type your name')
    name = input()
print('thank you')