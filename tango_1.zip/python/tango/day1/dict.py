#!/usr/bin/python 
d = { "x":1,"y":2,"z":3 }
for key in d:
    print(key,'match to',d[key])