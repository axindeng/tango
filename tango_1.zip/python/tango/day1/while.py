'''
name = ''
while not name:
    name = input('Please enter your name:')
print('hello,{}!'.format(name))
'''

num = ''
for num in range(1,100):
    print(num)

num = [1,2,3,4,5,6,7,8,9,0]
for n in num:
    print(n)