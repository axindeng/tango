def spam():
    print(eggs)
    eggs = 'spam local'
    print(eggs)

eggs = 'global'
spam()
