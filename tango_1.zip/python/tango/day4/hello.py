print('Hello',end='')
print('World')
print('eggs','dogs','cats')
print('eggs','dogs','cats',sep=',')