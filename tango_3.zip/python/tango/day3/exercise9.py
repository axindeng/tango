spam = 2

if spam == 1:
    print('Hello,you typed 1')
elif spam == 2:
    print('Howdy,you typed 2')
else:
    print('Greetings!,Now exit')
